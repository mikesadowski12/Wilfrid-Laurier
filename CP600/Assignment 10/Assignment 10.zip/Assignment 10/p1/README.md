# Assignment 10
## Problem 1:
* Run `python3 p1.py` inside this directory
* sample input: ``
* sample output: ``

## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`