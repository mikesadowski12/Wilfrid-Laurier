# Assignment 3
## Problem 3:
* Run `python3 p3.py` inside this directory
* sample input: `k = 3, temps = [20, 15, 10, 17]`
* sample output: `k-th smallest temperature is  17`
* IMPORTANT: Did NOT implement any error handling for the inputs. Script will fail when non-integers are inputted
## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`