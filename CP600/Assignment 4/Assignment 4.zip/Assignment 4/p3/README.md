# Assignment 4
## Problem 3: RadixSort
* Run `python3 p3.py` inside this directory
* sample input: `[418, 336, 457, 419, 386, 312, 310, 452]`
* sample output: `[310, 312, 336, 386, 418, 419, 452, 457]`

## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`