# Assignment 4
## Problem 2: InsertionSort/QuickSort
* Run `python3 p2.py` inside this directory
* sample input: `[104, 226, 3, 7, 69, 77, 144, 15, 29, 30, 31]`
* sample output: `[3, 7, 15, 29, 30, 31, 69, 77, 104, 144, 226]`

## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`