# Assignment 5
## Problem 2: BST Height-Balance
* Run `python3 p2.py` inside this directory
* sample input: `Balanced Tree 1, Unbalanced Tree 2`
* sample output: `Tree 1 isBalanced() is  True, Tree 2 isBalanced() is  False`
* see p2.txt for explanation to the question

## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`