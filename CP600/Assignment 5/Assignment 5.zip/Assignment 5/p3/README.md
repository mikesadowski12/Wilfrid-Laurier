# Assignment 5
## Problem 3:
* Run `python3 p3.py` inside this directory
* sample input: ``
* sample output: ``

## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`