# Assignment 5
## Problem 1: BST_Ceiling
* Run `python3 p1.py` inside this directory
* sample input: `Tree: [11, 3, 15, 1, 9, 12, 14]`
* sample output: `0 - 1,
1 - 1,
2 - 3,
3 - 3,
4 - 9,
5 - 9,
6 - 9,
7 - 9,
8 - 9,
9 - 9,
10 - 11,
11 - 11,
12 - 12,
13 - 15,
14 - 15,
15 - 15,
16 - -1,
17 - -1,
18 - -1,
19 - -1`

## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`