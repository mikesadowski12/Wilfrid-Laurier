# Assignment 11
## Problem 2:
* Run `python3 p2.py` inside this directory
* sample input: ``
* sample output: ``

## Notes:
* Ran assignment using `python3` command (shown above)
* `python3 --version` command returns `Python 3.6.4`