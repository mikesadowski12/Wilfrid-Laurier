//
//  Card.swift
//  sado2560_a2
//
//  Created by Mike Sadowski on 2021-02-06.
//

import Foundation;
import UIKit;

struct Card {
    let image:UIImage?;
    let question:String?;
    let answer:String?;
}
