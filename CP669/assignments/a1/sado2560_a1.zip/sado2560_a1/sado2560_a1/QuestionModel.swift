//
//  Question.swift
//  sado2560_a1
//
//  Created by Mike Sadowski on 2021-01-18.
//

import Foundation
import UIKit

struct QuestionModel {
    var image: UIImage?
    var question: String?
    var answer: String?
}
