//
//  FriendManager.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-12.
//

import UIKit

class FriendManager: NSObject, URLSessionTaskDelegate {
    static var friendManager = FriendManager();
    
    private var friends = [Friend]();
    
    private var searchFemales: Bool;
    private var searchMales: Bool;
    private var searchNationality: String;
    
    private let fileName = "friendsManager.archive";
    private let rootKey = "rootKey";
    
    func getFriends() -> [Friend] {
        return self.friends;
    }

    func getSearchFemales() -> Bool {
        return self.searchFemales;
    }
    
    func getSearchMales() -> Bool {
        return self.searchMales;
    }
    
    func getSearchNationality() -> String {
        return self.searchNationality;
    }
    
    func saveSettings(searchFemales: Bool, searchMales: Bool, searchNationality: String) {
        self.searchFemales = searchFemales;
        self.searchMales = searchMales;
        self.searchNationality = searchNationality;
    }
    
    func addFriend(friend: Friend) {
        self.friends.append(friend);
    }
    
    func removeFriend(position: Int) {
        if (self.friends.count > 0) {
            self.friends.remove(at: position);
        }
    }
        
    private func buildGenderURL() -> String {
        if (searchFemales && !searchMales) {
            return URL_FEMALE_ONLY;
        } else if (!searchFemales && searchMales) {
            return URL_MALE_ONLY;
        }
        
        return URL_ALL_GENDERS;
    }
    
    private func buildNationalityURL() -> String {
        return URL_NATIONALITY + searchNationality;
    }
    
    func buildURL() -> String {
        var url = "";
        
        url = url + BASE_URL;
        url = url + buildGenderURL();
        url = url + buildNationalityURL();
        
        return url;
    }
    
    // Define the path to the archive
    private func dataFilePath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(
            FileManager.SearchPathDirectory.documentDirectory,
            FileManager.SearchPathDomainMask.userDomainMask, true
        );
        let documentsDirectory = paths[0] as NSString;
        
        return documentsDirectory.appendingPathComponent(fileName) as String;
    }
    
    private func loadFriends() {
        let filePath = self.dataFilePath();
        
        if (FileManager.default.fileExists(atPath: filePath)) {
            let data = NSMutableData(contentsOfFile: filePath)!;
            let unarchiver = NSKeyedUnarchiver(forReadingWith: data as Data);
            friends = unarchiver.decodeObject(forKey: rootKey) as! [Friend];
            unarchiver.finishDecoding();
        } else {
            friends = [Friend]();
        }
    }
    
    func saveFriends() {
        let filePath = self.dataFilePath()
        let data = NSMutableData();
        let archiver = NSKeyedArchiver(forWritingWith: data);

        archiver.encode(FriendManager.friendManager.friends, forKey: rootKey);
        archiver.finishEncoding();
        data.write(toFile: filePath, atomically: true);
    }
            
    override init() {
        self.searchFemales = true;
        self.searchMales = true;
        self.searchNationality = "";
        
        super.init();
        loadFriends();
    }
}
