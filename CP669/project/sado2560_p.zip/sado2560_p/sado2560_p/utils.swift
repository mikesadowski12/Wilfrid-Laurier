//
//  utils.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-12.
//

import Foundation
// https://randomuser.me/api/?nat=gb
// https://randomuser.me/api/?gender=female

// https://randomuser.me/api/?gender=female&nat=gb
// https://randomuser.me/api/?gender=&nat=gb

let BASE_URL = "https://randomuser.me/api/"
let URL_ALL_GENDERS = "?gender="
let URL_FEMALE_ONLY = "?gender=female"
let URL_MALE_ONLY = "?gender=male"
let URL_NATIONALITY = "&nat="

let allowedNationalityValues: [String] = ["AU", "BR", "CA", "CH", "DE", "DK", "ES", "FI", "FR", "GB", "IE", "IR", "NL", "NZ", "TR", "US", ""];

func getCurrentDate() -> String {
    let currentDateTime = Date();
    let formatter = DateFormatter();
    
    formatter.timeStyle = .medium;
    formatter.dateStyle = .long;
    
    return formatter.string(from: currentDateTime);
}
