//
//  SettingsViewController.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-12.
//

import UIKit

class SettingsViewController: UIViewController {
    @IBOutlet weak var femaleSwitch: UISwitch!;
    @IBOutlet weak var maleSwitch: UISwitch!;
    @IBOutlet weak var nationalityBox: UITextField!;
    @IBOutlet weak var saveButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.femaleSwitch.isOn = FriendManager.friendManager.getSearchFemales();
        self.maleSwitch.isOn = FriendManager.friendManager.getSearchMales();
        self.nationalityBox.text = FriendManager.friendManager.getSearchNationality();
    }
    
    private func showErrorAlert(message: String) {
        let title = "Error";
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);
        
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil);
    }
    
    private func showSuccessAlert(message: String) {
        let title = "Saved";
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);
        
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil);
    }
    
    private func showGenderSwitchError() {
        let message = "At least 1 gender filter switch needs to be on";
        showErrorAlert(message: message);
    }
    
    private func showNationalityError() {
        let message = "Allowed values for nationality are: AU, BR, CA, CH, DE, DK, ES, FI, FR, GB, IE, IR, NL, NZ, TR, US or empty";
        showErrorAlert(message: message);
    }
    
    private func showSaveSuccess() {
        let message = "Settings successfully saved";
        showSuccessAlert(message: message);
    }
    
    @IBAction func femaleSwitchDidChange(_ sender: Any) {
        if (!maleSwitch.isOn && !femaleSwitch.isOn) {
            showGenderSwitchError();
            femaleSwitch.isOn = true;
        }
    }
    
    @IBAction func maleSwitchDidChange(_ sender: Any) {
        if (!maleSwitch.isOn && !femaleSwitch.isOn) {
            showGenderSwitchError();
            maleSwitch.isOn = true;
        }
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        if !allowedNationalityValues.contains(nationalityBox.text!) {
            showNationalityError()
        } else {
            FriendManager.friendManager.saveSettings(searchFemales: femaleSwitch.isOn, searchMales: maleSwitch.isOn, searchNationality: nationalityBox.text!);
            showSaveSuccess();
        }
    }
}
