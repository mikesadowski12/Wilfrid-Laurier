//
//  ViewController.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-11.
//

import UIKit

class FindViewController: UIViewController {
    private let fm = FriendManager();
    
    private var candidateFriend:Friend?;
    var dataStore = NSData();
    var personItem: PersonItem?;
    
    @IBOutlet weak var image: UIImageView!;
    @IBOutlet weak var name: UILabel!;
    @IBOutlet weak var age: UILabel!;
    @IBOutlet weak var location: UILabel!;
    @IBOutlet weak var phoneNumber: UILabel!;
    @IBOutlet weak var emailAddress: UILabel!;
    
    private func loadNewCandidateFriend() {
        self.image.image = candidateFriend!.getImage();
        self.name.text = candidateFriend!.getName();
        self.age.text = String(candidateFriend!.getAge()) + " years old";
        self.location.text = candidateFriend!.getCity() + " " + candidateFriend!.getState() + ", " + candidateFriend!.getCountry();
        self.phoneNumber.text = candidateFriend!.getPhoneNumber();
        self.emailAddress.text = candidateFriend!.getEmailAddress();
    }
    
    func fetchCandidateFriend() {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true; // from course notes, not sure how to get warnings to disappear
        
        let url: NSURL = NSURL(string: FriendManager.friendManager.buildURL())!
        let request: URLRequest = URLRequest(url: url as URL)
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(
            with: request,
            completionHandler:{ (data, response, error) in
                self.dataStore = data! as NSData
                let _ = NSString(data: self.dataStore as Data, encoding: String.Encoding.utf8.rawValue)

                if let r = error {
                    print(r)
                }

                do {
                    self.personItem = try JSONDecoder().decode(PersonItem.self, from: self.dataStore as Data);

                    DispatchQueue.main.async { // must handle UI methods in the main thread
                        self.candidateFriend = self.personItem?.createFriendObj();
                        
                        let imageQueue = DispatchQueue(label: "Image Queue", attributes:  .concurrent);
                        imageQueue.async {  // put the image downloading operation in a dispatch queue
                            let url = NSURL(string: self.candidateFriend!.getImageUrl())
                            let imageData  = NSData(contentsOf: url! as URL)
                            let image = UIImage(data: imageData! as Data) // get our image
                            
                            self.candidateFriend?.setImage(image: image!);
                            
                            DispatchQueue.main.async {
                                UIApplication.shared.isNetworkActivityIndicatorVisible = false; // from course notes, not sure how to get warnings to disappear
                                self.loadNewCandidateFriend();
                            };
                        }
                        
                        self.loadNewCandidateFriend();
                    }
                } catch let jsonError as NSError {
                    print("JSON decode failed: \(jsonError.localizedDescription)")
                    return
                } // catch - do
            }) //dataTask""
        
        task.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        fetchCandidateFriend();
    }
    
    private func showSuccessAlert(message: String) {
        let title = "Friend Added";
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);
        
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil);
    }

    @IBAction func addFriendPressed(_ sender: Any) {
        FriendManager.friendManager.addFriend(friend: self.candidateFriend!);
        showSuccessAlert(message: "\(self.candidateFriend?.getName() ?? "") was added to your friends list");
        fetchCandidateFriend();
    }
    
    @IBAction func nextPersonPressed(_ sender: Any) {
        fetchCandidateFriend();
    }
}

