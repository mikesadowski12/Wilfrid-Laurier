//
//  FriendsListTableViewController.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-12.
//

import UIKit;

class TableViewCell: UITableViewCell {
    @IBOutlet weak var friendImage: UIImageView!
    @IBOutlet weak var friendName: UILabel!;
}

class FriendsListTableViewController: UITableViewController, UISearchBarDelegate {
    @IBOutlet weak var searchBar: UISearchBar!
    var filteredData = [Friend]();
    
    override func viewDidLoad() {
        super.viewDidLoad();
        filteredData = FriendManager.friendManager.getFriends();
        tableView.reloadData();
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated);
        searchBar.text = "";
        filteredData = FriendManager.friendManager.getFriends();
        tableView.reloadData();
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
       guard !searchText.isEmpty else {
        filteredData = FriendManager.friendManager.getFriends();
          tableView.reloadData()
          return
       }
        
        let originalData = FriendManager.friendManager.getFriends();
       filteredData = originalData.filter({ person  -> Bool in
          person.getName().contains(searchText)
       })
       tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let deletedFriend = FriendManager.friendManager.getFriends()[indexPath.row];
            FriendManager.friendManager.removeFriend(position: indexPath.row);
            if (filteredData.count > 0) {
                filteredData.remove(at: indexPath.row);
            }
            tableView.deleteRows(at: [indexPath], with: .fade);
            let title = "Friend Removed";
            let alertController = UIAlertController(title: title, message: "\(deletedFriend.getName()) was removed from your friend list", preferredStyle: UIAlertController.Style.alert);
            
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil);
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath)
                as? TableViewCell;

        if (cell == nil) {
          cell = TableViewCell(
            style: UITableViewCell.CellStyle.default,
            reuseIdentifier: "FriendCell");
        }
        
        cell?.friendImage.image = filteredData[indexPath.row].getImage();
        cell?.friendName.text = filteredData[indexPath.row].getName();

        return cell!;
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender);
        
        switch(segue.identifier ?? "") {
            case "ShowFriend":
                guard let friendDetailViewController = segue.destination as? FriendDetailViewController else {
                    fatalError("Unexpected destination: \(segue.destination)");
                }
                
                guard let selectedFriendCell = sender as? TableViewCell else {
                    fatalError("Unexpected sender: \(sender as Optional)");
                }
                
                guard let indexPath = tableView.indexPath(for: selectedFriendCell) else {
                    fatalError("The selected cell is not being displayed by the table");
                }

                let friend = filteredData[indexPath.row];
                friendDetailViewController.friend = friend;
                
            default:
                fatalError("Unexpected Segue Identifier; \(segue.identifier as Optional)");
        }
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
