//
//  Person.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-13.
//

import UIKit;
import Foundation;

class Name: Decodable {
    let first : String
    let last : String
    
    init() {
        self.first = "";
        self.last = "";
    }
}

class DOB: Decodable {
    let age: Int;
    
    init() {
        self.age = 0;
    }
}

class Location: Decodable {
    let country : String
    let state : String
    let city : String
    
    init() {
        self.country = "";
        self.state = "";
        self.city = "";
    }
}

class Picture: Decodable {
    let large : String
    
    init() {
        self.large = "";
    }
}

class Person: Decodable {
    let name: Name;
    let dob: DOB;
    
    let location: Location;
    
    let cell: String;
    let email: String;
    
    let picture: Picture;
}

class PersonItem: Decodable {
    let results: [Person];
    
    func createFriendObj() -> Friend {
        let friend = Friend(image: UIImage(named: "profile.png"), name: "\(results[0].name.first) \(results[0].name.last)", age: results[0].dob.age, phoneNumber: "\(results[0].cell)", emailAddress: "\(results[0].email)", country: "\(results[0].location.country)", state: "\(results[0].location.state)", city: "\(results[0].location.city)", imageUrl: "\(results[0].picture.large)");
        
        return friend!;
    }
}
