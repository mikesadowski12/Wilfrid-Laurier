//
//  FriendDetailViewController.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-12.
//

import UIKit

class FriendDetailViewController: UIViewController {
    var friend:Friend?;
    
    @IBOutlet weak var image: UIImageView!;
    @IBOutlet weak var name: UILabel!;
    @IBOutlet weak var age: UILabel!;
    @IBOutlet weak var location: UILabel!;
    @IBOutlet weak var phoneNumber: UILabel!;
    @IBOutlet weak var emailAddress: UILabel!;
    @IBOutlet weak var dateOfFriendship: UILabel!;
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.image.image = friend!.getImage();
        self.name.text = friend!.getName();
        self.age.text = String(friend!.getAge()) + " years old";
        self.location.text = friend!.getCity() + " " + friend!.getState() + ", " + friend!.getCountry();
        self.phoneNumber.text = friend!.getPhoneNumber();
        self.emailAddress.text = friend!.getEmailAddress();
        self.dateOfFriendship.text = "Friend since " + friend!.getDateOfFriendship();
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated);
    }
}
