//
//  Person.swift
//  sado2560_p
//
//  Created by Mike Sadowski on 2021-04-12.
//

import UIKit;

class Friend: NSObject, NSCoding {
    private var image: UIImage?;
    private let name: String;
    private let age: Int;
    
    private let phoneNumber: String;
    private let emailAddress: String;
    
    private let country: String;
    private let state: String;
    private let city: String;
    
    private let dateOfFriendship: String;
    private let imageUrl: String;
        
    func getImage() -> UIImage {
        return self.image!;
    }
    
    func setImage(image: UIImage) {
        self.image = image;
    }
    
    func getName() -> String {
        return self.name;
    }
    
    func getAge() -> Int {
        return self.age;
    }
    
    func getCountry() -> String {
        return self.country;
    }
    
    func getState() -> String {
        return self.state;
    }
    
    func getCity() -> String {
        return self.city;
    }
    
    func getPhoneNumber() -> String {
        return self.phoneNumber;
    }
    
    func getEmailAddress() -> String {
        return self.emailAddress;
    }
    
    func getDateOfFriendship() -> String {
        return self.dateOfFriendship;
    }
    
    func getImageUrl() -> String {
        return self.imageUrl;
    }
    
    init?(image: UIImage?, name: String, age: Int, phoneNumber: String, emailAddress: String, country: String, state: String, city: String, dateOfFriendship: String = getCurrentDate(), imageUrl: String) {
        self.image = image;
        self.name = name;
        self.age = age;
        
        self.phoneNumber = phoneNumber;
        self.emailAddress = emailAddress;
        
        self.country = country;
        self.state = state;
        self.city = city;
        
        self.dateOfFriendship = dateOfFriendship;
        self.imageUrl = imageUrl;
    } //init?
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(image, forKey: PropertyKey.image);
        aCoder.encode(name, forKey: PropertyKey.name);
        aCoder.encode(age, forKey: PropertyKey.age);
        
        aCoder.encode(phoneNumber, forKey: PropertyKey.phoneNumber);
        aCoder.encode(emailAddress, forKey: PropertyKey.emailAddress);
        
        aCoder.encode(country, forKey: PropertyKey.country);
        aCoder.encode(state, forKey: PropertyKey.state);
        aCoder.encode(city, forKey: PropertyKey.city);
        
        aCoder.encode(dateOfFriendship, forKey: PropertyKey.dateOfFriendship);
        aCoder.encode(imageUrl, forKey: PropertyKey.imageUrl);
    } //encode
    
    required convenience init?(coder aDecoder: NSCoder) {
        let image = aDecoder.decodeObject(forKey: PropertyKey.image) as? UIImage;
        let name = aDecoder.decodeObject(forKey: PropertyKey.name) as? String;
        let age = aDecoder.decodeInteger(forKey: PropertyKey.age);
        
        let phoneNumber = aDecoder.decodeObject(forKey: PropertyKey.phoneNumber) as? String;
        let emailAddress = aDecoder.decodeObject(forKey: PropertyKey.emailAddress) as? String;
        
        let country = aDecoder.decodeObject(forKey: PropertyKey.country) as? String;
        let state = aDecoder.decodeObject(forKey: PropertyKey.state) as? String;
        let city = aDecoder.decodeObject(forKey: PropertyKey.city) as? String;
        
        let dateOfFriendship = aDecoder.decodeObject(forKey: PropertyKey.dateOfFriendship) as? String;
        let imageUrl = aDecoder.decodeObject(forKey: PropertyKey.imageUrl) as? String;

        // Must call designated initializer.
        self.init(image: image, name: name!, age: age, phoneNumber: phoneNumber!, emailAddress: emailAddress!, country: country!, state: state!, city: city!, dateOfFriendship: dateOfFriendship!, imageUrl: imageUrl!);
    } // decode
}

struct PropertyKey {
    static let image = "image";
    static let name = "name";
    static let age = "age";
    
    static let phoneNumber = "phoneNumber";
    static let emailAddress = "emailAddress";
    
    static let country = "country";
    static let state = "state";
    static let city = "city";
    
    static let dateOfFriendship = "dateOfFriendship";
    static let imageUrl = "imageUrl";
}
