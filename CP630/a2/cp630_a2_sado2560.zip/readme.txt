Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-a2
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, R - Requirement
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

A2

A2
Q1 JMS and MDB for data collection and stats

Q1.1 MDB for stats                        [10/10/*]
Q1.2 MDB for adding and saving data       [10/10/*]
Q1.3 Standalone JMS clients               [10/10/*]
Q1.4 JMS clients in Web components        [10/10/*]
Q1.5 JMS clients in Session beans         [10/10/*]

Q2 Data persistence with stats application

Q2.1 Database table and client            [10/10/*]
Q2.2 User entity bean                     [10/10/*]
Q2.3 Model entity bean                    [10/10/*]
Q2.4 EJB using entities                   [10/10/*]
Q2.5 Entity EJB Web access                [10/10/*]

Total:                                    [100/100/*]
