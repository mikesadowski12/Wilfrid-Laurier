Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-lab5
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

Lab5

T1 Apache Cassandra
T1.1 Install, configure, and run          [3/3/*]
T1.2 CQL operations by cqlsh              [4/4/*]
T1.3 CQL programming by Java API          [4/4/*]

T2 Apache Hadoop and HDFS
T2.1 Install, configure, and start        [3/3/*]
T2.2 HDFS CLI operations                  [4/4/*]

T3 Hadoop MapReduce
T3.1 Word counter example                 [4/4/*]
T3.2 Kmeans by Hadoop MapReduce           [3/3/*]
T3.3 Hadoop client programming            [3/3/*]

T4 Apache Spark
T4.1 Install, configuration, start        [3/3/*]
T4.2 Spark operations in Scala shell      [3/3/*]
T4.3 MapReduce with Spark                 [3/3/*]

T5 Spark Programming
T5.1 Spark programming in Java            [3/3/*]

Total:                                    [40/40/*]
