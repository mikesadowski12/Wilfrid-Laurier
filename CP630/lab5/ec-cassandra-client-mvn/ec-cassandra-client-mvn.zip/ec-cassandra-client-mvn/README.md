# EC Cassandra CQL client
Author: HBF  
Date: 2020-11-08 (update)  

This project is to test Cassandra CQL client programming using Cassandra API. 

## Test

1. Start Cassandra if it is not running. 
2. ECCQLClient.java as Java application. 

