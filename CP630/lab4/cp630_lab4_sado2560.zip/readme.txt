Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-lab3
WorkID: cp630-lab4
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

Lab4

T1 Spring Framework
T1.1 Hand on IoC                          [2/2/*]
T1.2 Hand on AOP                          [2/2/*]
T1.3 Web component of Spring MVC          [3/3/*]
T1.4 Spring Boot Web applications         [3/3/*]
T1.5 Spring on WildFly                    [2/2/*]

T2 OSGi Framework
T2.1 Equinox OSGi framework               [2/2/*]
T2.2 Create OSGi bundles in Eclipse       [4/4/*]
T2.3 Apache Felix OSGi framework          [2/2/*]
T2.4 Apache Karaf                         [2/2/*]

T3 OSGi Service Bundle development
T3.1 OSGi service bundle                  [2/2/*]
T3.2 ec-osgi-consumer bundle              [2/2/*]
T3.3 Web application bundles              [2/2/*]
T3.4 Servlet bundles                      [2/2/*]

T4 Docker
T4.1 Install Docker and operations        [3/3/*]
T4.2 Creating docker images               [3/3/*]

T5 Container orchestration
T5.1 Install and run Microk8s             [2/2/*]
T5.2 Basic operations on Microk8s         [2/2/*]

Total:                                    [40/40/*]
