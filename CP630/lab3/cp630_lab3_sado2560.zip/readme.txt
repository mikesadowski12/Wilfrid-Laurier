Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-lab3
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

Lab3

T1 SOAP Web Services
T1.1 Red Hat Developer Studio             [2/2/*]
T1.2 Quickstart helloworld-ws             [2/2/*]
T1.3 SOAP WS ec-ws project                [3/3/*]
T1.4 WS ec-ws-client project              [3/3/*]
T1.5 Web service with interfaces          [3/3/*]
T1.6 Access WS by Servlet                 [3/3/*]

T2 RESTful Web Services
T2.1 Quickstart helloworld-rs             [2/2/*]
T2.2 RESTful WS project ec-rs             [3/3/*]

T3 Web tier - Servlet, JSP, JSF
T3.1 Servlet API programming              [3/3/*]
T3.2 Simple login example                 [3/3/*]
T3.3 Hand on JSP                          [3/3/*]
T3.4 Hand on JSF                          [3/3/*]

T4 Client tier components
T4.1 Java HTTP client project             [3/3/*]
T4.2 JavaScript & jQuery components       [2/2/*]
T4.3 JavaScript & React components        [2/2/*]

Total:                                    [40/40/*]
