Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-a5
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, R - Requirement
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

A5

A5
Q1 Stats by Hadoop MapReduce

Q1.1 HDMR programming for stats           [0/15/*]
Q1.2 HDFS programming for stats           [0/10/*]
Q1.3 EC integration                       [0/5/*]

Q2 Spark exploration and EC integration

Q2.1 Spark RDD                            [5/5/*]
Q2.2 Spark SQL                            [5/5/*]
Q2.3 Spark Machine Learning               [5/5/*]
Q2.4 SparkX                               [5/5/*]
Q2.5 Spark model for EC                   [0/10/*]

Q3 EC trend

Q3.1 Research for EC subjects             [10/10/*]

Total:                                    [35/70/*]
