package ec.lr;

//import weka.core.Instances;

public interface LRStatelessLocal {
	public String prediction();
}
