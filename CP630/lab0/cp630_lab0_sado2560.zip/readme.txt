Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-lab0
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

Lab0

T1 Java JRE & SDK
T1.1 Install JRE and JDK                  [2/2/*]

T2 Build tools
T2.1 Apache Maven                         [2/2/*]
T2.2 Apache Ant                           [2/2/*]
T2.3 Eclipse JEE                          [2/2/*]

T3 Warm up projects
T3.1 ec-junit-log                         [2/2/*]
T3.2 ec-junit-log                         [2/2/*]
T3.3 ec-junit-log                         [2/2/*]
T3.4 ec-file-io                           [2/2/*]
T3.5 ec-stats                             [2/2/*]
T3.6 ec-regression                        [2/2/*]

Total:                                    [20/20/*]
