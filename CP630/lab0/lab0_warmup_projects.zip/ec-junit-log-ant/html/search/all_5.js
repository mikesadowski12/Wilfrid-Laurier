var searchData=
[
  ['initcalculator',['initCalculator',['../classec_1_1lab_1_1_cal_test.html#a092d5705f42e9a649e1ecd50461cf75e',1,'ec.lab.CalTest.initCalculator()'],['../classec_1_1lab_1_1_cal_test2.html#a704431de39dd283ba2820299fcb85a63',1,'ec.lab.CalTest2.initCalculator()']]]
];
