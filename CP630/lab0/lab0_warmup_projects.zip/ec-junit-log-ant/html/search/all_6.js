var searchData=
[
  ['logger',['logger',['../classec_1_1lab_1_1_my_calculator.html#a4383b2cd7fb2a0eff4f0f5df49cc249b',1,'ec::lab::MyCalculator']]]
];
