# EJB Client Project
Author: HBF  
Date: 2020-09-26 (update)  

- This is a build up project to practice EJB client : session beans. 
- It is used to test EJB session beans part of Lab1 and Lab2. 
- In Lab2 Task 5.4, the EJBClient2 access remote Stateful bean, which accesses singleton SecurityGuard for user validation. 
   
This project is provided as a trouble shooting help.
  