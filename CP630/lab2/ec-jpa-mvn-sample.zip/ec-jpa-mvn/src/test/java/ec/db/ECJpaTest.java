package ec.db;

import static org.junit.Assert.*;
import java.sql.SQLException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import ec.jpa.model.User;
import ec.jpa.repository.UserRepository;

public class ECJpaTest {	
	
    static EntityManager entityManager; 
    static UserRepository userrepository;
    static Integer id;
    static String name = "test";
    

	@BeforeClass
	public static void init() throws Exception, SQLException {
	    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("ec-jpa");
	    entityManager = entityManagerFactory.createEntityManager();
	    userrepository = new UserRepository(entityManager);
	}

	@Before
	public void beforeEachTest() throws Exception, SQLException {
		System.out.println("This is executed before each Test");
	}
	
	@Test
	public void test() {
	    User user = new User(name);
	    User savedUser = userrepository.save(user);
	    id = savedUser.getId();
	    System.out.println("id:"+id);
	    User findUser = userrepository.findById(id);
	    System.out.println("user:" +  findUser.toString());
	    assertEquals(name, findUser.getName());
	    userrepository.removeUserByID(id);
	}	
	
	@After
	public void afterEachTest() throws SQLException {
		System.out.println("This is exceuted after each Test");
		
	}
}
