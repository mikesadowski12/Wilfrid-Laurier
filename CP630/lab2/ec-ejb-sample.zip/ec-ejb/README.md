# EJB Lab Project
Author: HBF  
Date: 2020-09-26 (update)  

This is a build up project to practice EJB : sesson beans, message driven beans (MDB), and entity beans. 

1. EJB session bean part is from Lab1
2. MDB part is for Lab2, it needs ec-jms-client-mvn  to test the MDB. 
3. Entity part is from Lab2 task 5.4, it require ec-ejb-client to test the entity bean. 

This project is provided as a trouble shooting help.