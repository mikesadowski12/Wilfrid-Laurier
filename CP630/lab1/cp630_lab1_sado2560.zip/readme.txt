Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-lab1
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: T -- Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

Lab1

T1 WildFly (JBoss-AS)
T1.1 JBoss-AS installation                [3/3/*]
T1.2 Set admin and user                   [3/3/*]

T2 Build and deploy applications by Maven
T2.1 Install quickstart projects          [3/3/*]
T2.2 Testing helloworld project           [3/3/*]

T3 JBoss-AS Maven on Eclipse JEE
T3.1 Eclipse Maven and external JBoss     [3/3/*]
T3.2 Run WildFly within Eclipse JEE       [3/3/*]

T4 Hand-on EJB projects
T4.1 Test ejb-remote project              [3/3/*]
T4.2 Create EJB components                [6/6/*]
T4.3 Client component                     [4/4/*]

T5 Hand-on Web component
T5.1 Web component of Servlet             [3/3/*]
T5.2 Web components using EJB             [3/3/*]
T5.3 Application component deployment     [3/3/*]

Total:                                    [40/40/*]
