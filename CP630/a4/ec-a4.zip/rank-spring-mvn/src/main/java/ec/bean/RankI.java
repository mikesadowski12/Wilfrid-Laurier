package ec.bean;

public interface RankI {
	String getGrade(int s);
	int getRank(int s);
}