package ec.bean;

public interface GradeI {
	String getLetterGrade(int numerical_grade);
	void printLetterGrades(int start, int end);
}
