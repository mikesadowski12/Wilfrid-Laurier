package ec.lab;

public interface ModelI {
    Model getModelByName(String modelname);	
	void saveModel(Model model);
}
