package ec.lab;

public interface RankI {
	String getGrade(int s);
	int getRank(int s);
}