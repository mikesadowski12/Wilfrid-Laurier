Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-a4
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

A4

Q1 Spring framework based EC application
Q1.1 Grade Spring bean                    [10/10/*]
Q1.2 Rank Spring bean                     [10/10/*]
Q1.3 Rank Spring microservice             [10/10/*]
Q1.4 Linear regression microservices      [10/10/*]

Q2 OSGi based EC application
Q2.1 stats-osgi-service                   [20/20/*]
Q2.2 stats-osgi-consumer                  [10/10/*]
Q2.3 Web component                        [10/10/*]

Total:                                    [80/80/*]
