Name: Mike Sadowski
ID: 215802560
Email: sado2560@mylaurier.ca
WorkID: cp630-a1
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, R - Requirement
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*].
If marker gives different evaluation value say 1, it will show
[2/2/1] in the marking report.

Evaluation grid: [self-evaluation/total/marker-evaluation]

A1

A1
Q1 EC story

Q1.1 What it is ...                       [5/5/*]
Q1.2 How it works ...                     [5/5/*]
Q1.3 Platform technology ...              [5/5/*]
Q1.4 Overall ...                          [5/5/*]

Q2 Descriptive statistics project

Q2.1 Interface design                     [5/5/*]
Q2.2 Implementation                       [20/20/*]
Q2.3 Unit test                            [5/5/*]
Q2.4 Main program                         [5/5/*]
Q2.5 Logging and documentation            [5/5/*]
Q2.6 Build by ANT                         [5/5/*]

Q3 Java EE project on stats

Q3.1 stats-ejb project                    [20/20/*]
Q3.2 stats-ejb-client project             [5/5/*]
Q3.3 stats-ejb-web project                [5/5/*]
Q3.4 stats-ejb-web-ear project            [5/5/*]

Total:                                    [100/100/*]
