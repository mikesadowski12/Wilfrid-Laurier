var searchData=
[
  ['inputdata',['inputData',['../classec_1_1stats_1_1test_1_1_statistics_test.html#a3063451d101f1b5907163c25a6190742',1,'ec::stats::test::StatisticsTest']]]
];
