var searchData=
[
  ['max',['max',['../classec_1_1stats_1_1_e_c_statistics.html#a19e6ecf5598b25b0b6a795647aaf3951',1,'ec::stats::ECStatistics']]],
  ['mean',['mean',['../classec_1_1stats_1_1_e_c_statistics.html#a4d5d399c8bdc4c13ac193fa4b9a19d7d',1,'ec::stats::ECStatistics']]],
  ['min',['min',['../classec_1_1stats_1_1_e_c_statistics.html#ad1cccc73d83a11769ac6c5c416c7e635',1,'ec::stats::ECStatistics']]]
];
