var searchData=
[
  ['totalsum',['totalSum',['../classec_1_1stats_1_1_e_c_statistics.html#a15fe0613040c137f7a71c5de4f0e8bfc',1,'ec::stats::ECStatistics']]]
];
