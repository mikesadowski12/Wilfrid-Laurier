var searchData=
[
  ['adddata',['addData',['../classec_1_1stats_1_1_e_c_statistics.html#a6529c36c2e76dcebd8d81f5d7510eb50',1,'ec.stats.ECStatistics.addData()'],['../interfaceec_1_1stats_1_1_statistics.html#a30a29202a848ea2c20bfb23567c797b5',1,'ec.stats.Statistics.addData()']]]
];
