var searchData=
[
  ['computetotalstd',['computeTotalSTD',['../classec_1_1stats_1_1_e_c_statistics.html#a89857f7a47ae0c7f697c0dc889425311',1,'ec::stats::ECStatistics']]]
];
