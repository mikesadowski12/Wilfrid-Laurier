var searchData=
[
  ['ecstatistics',['ECStatistics',['../classec_1_1stats_1_1_e_c_statistics.html',1,'ec::stats']]]
];
