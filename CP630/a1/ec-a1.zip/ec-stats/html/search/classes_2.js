var searchData=
[
  ['statistics',['Statistics',['../interfaceec_1_1stats_1_1_statistics.html',1,'ec::stats']]],
  ['statisticstest',['StatisticsTest',['../classec_1_1stats_1_1test_1_1_statistics_test.html',1,'ec::stats::test']]]
];
