var searchData=
[
  ['getcount',['getCount',['../classec_1_1stats_1_1_e_c_statistics.html#a2dd48a948c6790d2343bb6ad5a8fbdec',1,'ec.stats.ECStatistics.getCount()'],['../interfaceec_1_1stats_1_1_statistics.html#acd559690f45eb64880063b3057a61f0d',1,'ec.stats.Statistics.getCount()']]],
  ['getmax',['getMax',['../classec_1_1stats_1_1_e_c_statistics.html#a8b2714fd78189774569a9e8fdd4ab616',1,'ec.stats.ECStatistics.getMax()'],['../interfaceec_1_1stats_1_1_statistics.html#a0a53dbdd5b6f5d715042df07e31a21d8',1,'ec.stats.Statistics.getMax()']]],
  ['getmean',['getMean',['../classec_1_1stats_1_1_e_c_statistics.html#a510f764444291c56c80ba03cd620e743',1,'ec.stats.ECStatistics.getMean()'],['../interfaceec_1_1stats_1_1_statistics.html#a04f832519ec62cbbcdb8f7fa940917a3',1,'ec.stats.Statistics.getMean()']]],
  ['getmin',['getMin',['../classec_1_1stats_1_1_e_c_statistics.html#a6bf9d8b0d5bc4700a37247d7cc90fe17',1,'ec.stats.ECStatistics.getMin()'],['../interfaceec_1_1stats_1_1_statistics.html#a3618834484a79787bcf3d04177be8a70',1,'ec.stats.Statistics.getMin()']]],
  ['getstd',['getSTD',['../classec_1_1stats_1_1_e_c_statistics.html#a6944951db00482e534e10c4c9bf5c968',1,'ec.stats.ECStatistics.getSTD()'],['../interfaceec_1_1stats_1_1_statistics.html#a2b6675be6da443c30d3da7796031b8ab',1,'ec.stats.Statistics.getSTD()']]]
];
