var searchData=
[
  ['computetotalstd',['computeTotalSTD',['../classec_1_1stats_1_1_e_c_statistics.html#a89857f7a47ae0c7f697c0dc889425311',1,'ec::stats::ECStatistics']]],
  ['count',['count',['../classec_1_1stats_1_1_e_c_statistics.html#aca5935502fe759a6b6c6d5c56a31aeca',1,'ec::stats::ECStatistics']]]
];
