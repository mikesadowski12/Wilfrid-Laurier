var searchData=
[
  ['statistics',['Statistics',['../interfaceec_1_1stats_1_1_statistics.html',1,'ec::stats']]],
  ['statistics_2ejava',['Statistics.java',['../_statistics_8java.html',1,'']]],
  ['statisticstest',['StatisticsTest',['../classec_1_1stats_1_1test_1_1_statistics_test.html',1,'ec::stats::test']]],
  ['statisticstest_2ejava',['StatisticsTest.java',['../_statistics_test_8java.html',1,'']]],
  ['stats',['stats',['../classec_1_1stats_1_1_e_c_statistics.html#ae8230870f1079b3efbc7681c96f35d7f',1,'ec.stats.ECStatistics.stats()'],['../interfaceec_1_1stats_1_1_statistics.html#a98e67195828a4abc6c53e074c5229a18',1,'ec.stats.Statistics.stats()']]],
  ['std',['std',['../classec_1_1stats_1_1_e_c_statistics.html#a3760311b9e2e1a1f32206543e96da215',1,'ec::stats::ECStatistics']]]
];
