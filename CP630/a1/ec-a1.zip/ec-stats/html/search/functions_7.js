var searchData=
[
  ['stats',['stats',['../classec_1_1stats_1_1_e_c_statistics.html#ae8230870f1079b3efbc7681c96f35d7f',1,'ec.stats.ECStatistics.stats()'],['../interfaceec_1_1stats_1_1_statistics.html#a98e67195828a4abc6c53e074c5229a18',1,'ec.stats.Statistics.stats()']]]
];
